<?php

define('ROOT_DIR', '/Applications/MAMP/htdocs/a2a/');
define('ENCRYPTION_KEY', "i miss ann arbor");
define('SHOW_ADS', false);
define('SHOW_ANALYTICS', false);
define('JS_PACKED', false);
define('DB_USER', 'a2a');
define('DB_PW', 'd#$d&tr##', 'a2a');
define('DB_SCHEMA', 'a2a');

?>
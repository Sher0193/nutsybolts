<?php

/***
 * game.php
 * This script displays the page where A2A is actually played.
 * It loads the player list, hand and any chat messages from the landing page.
 * 
 * Error conditions:
 * o Room does not exist
 * o Room has not started playing
 * o Player is not in room
 */

require_once('./config.php');
require_once(MODEL_DIR . 'Room.php');
require_once(MODEL_DIR . 'Player.php');
require_once(MODEL_DIR . 'RedCard.php');
require_once(MODEL_DIR . 'GamePackage.php');
require_once(LIB_DIR . 'A2ASmartyWrapper.php');

// get the room ID number from the URL
$path_info = substr($_SERVER['PATH_INFO'], 1);
list($room_id, $player_hash) = explode('_', $path_info, 2);

$smarty = new A2ASmartyWrapper();

try {
	$room = new Room($room_id);
	if (!$room->load()) {
		// generic database failure / room doesn't exist
		// send the user back home with an error message
		header('Location: /index.php?status=-1');
		exit;
	}
	
	if (!$room->getStatus()) {
		// send them back to the landing page if the game hasn't started
		header('Location: /landing.php/' . $path_info);
		exit;
	}
	
	// make sure the player is in the game.
	$player_id = $room->getPlayerIDFromHash($player_hash);
	if ($player_id == -1) {
		// kick the player out if he doesn't belong
		header('Location: /index.php?status=-5');
		exit;	
	}
	
	$your_password = $room->getPasswordFromHash($player_hash);
	
	$package = $room->getPackage($player_id);
	if (!$package->validatePlayer($player_id)) {
		// kick the player out if he doesn't belong
		header('Location: /index.php?status=-5');
		exit;
	}
	
	$smarty->assign('player_id', $player_id);
	$smarty->assign('players', $package->getPlayers());
	$smarty->assign('creator_flag', $package->isCreator($player_id));
	$smarty->assign('room_id', $room_id);
	$smarty->assign('password', $your_password);
	$smarty->assign('room_name', $room->getName());
	$smarty->assign('hand', $package->getHand());
	$smarty->assign('messages', $package->getMessages());
	$smarty->assign('green_card', $package->getGreenCard());
	$smarty->assign('judge_name', $package->getJudgeName());
	$smarty->assign('is_judge', $package->isJudge($player_id));
	$smarty->assign('current_judge', $package->getJudgeNumber());
	$smarty->assign('round_number', $package->getRoundNumber());
	$smarty->assign('max_rounds', $room->getMaxRounds());
	$smarty->assign('played_flag', $package->hasPlayed($player_id));
	$smarty->assign('history', $package->getHistory());
	$smarty->assign('log_id', $package->getLogID());
	$smarty->assign('played_cards', $package->getPlayedCards());
	$smarty->assign('phase', $package->getPhase());
	$smarty->assign('PACKED', JS_PACKED);
	$smarty->assign('ANALYTICS', SHOW_ANALYTICS);
	$smarty->assign('SHOW_ADS', SHOW_ADS);
	$smarty->display('game-beta.tpl');
}
catch (DatabaseException $e) {
	$smarty->display('failwhale.tpl');
}

?>
<?php

require_once('./config/' . $_SERVER['SERVER_NAME']);

?>
function playSound(sound) {
	if ($('#mutesounds').attr('checked') == 'checked')
		return;
	
	var audio = document.getElementById('sound-' + sound);
	if (audio && audio.play) {
		audio.play();
	}
}

<?php

/***
 * Landing.php
 * This script services the "landing page" where people can gather and chat before the game starts.
 * The game creator can deal the cards and start the game at any point.
 * 
 ***/

require_once('./config.php');
require_once(MODEL_DIR . 'Room.php');
require_once(MODEL_DIR . 'Player.php');
require_once(MODEL_DIR . 'LandingPackage.php');
require_once(LIB_DIR . 'A2ASmartyWrapper.php');

// get the room ID number from the URL
$path_info = substr($_SERVER['PATH_INFO'], 1);
list($room_id, $player_hash) = explode('_', $path_info, 2);
$smarty = new A2ASmartyWrapper();

try {
	$room = new Room($room_id);
	if (!$room->load()) {
		// generic database failure / room doesn't exist
		// send the user back home with an error message
		header('Location: /index.php?status=-1');
		exit;
	}
	if ($room->getStatus()) {
		// send them along to the game if the room has already started
		header('Location: /game.php/' . $path_info);
		exit;
	}
	
	$player_id = $room->getPlayerIDFromHash($player_hash);
	
	if ($player_id == -1) {
		// kick the player out if he doesn't belong
		header('Location: /index.php?status=-5');
		exit;
	}
	
	$your_password = $room->getPasswordFromHash($player_hash);
	
	$package = $room->getPackage($player_id);
	if (!$package->validatePlayer($player_id)) {
		// kick the player out if he doesn't belong
		header('Location: /index.php?status=-5');
		exit;
	}
	
	$smarty->assign('creator_flag', $package->isCreator($player_id));
	$smarty->assign('creator', $package->getCreatorName());
	$smarty->assign('player_id', $player_id);
	$smarty->assign('players', $package->getPlayers());
	$smarty->assign('messages', $package->getMessages());
	$smarty->assign('room_id', $room_id);
	$smarty->assign('room_pw', $room->getPassword());
	$smarty->assign('password', $your_password);
	$smarty->assign('room_name', $room->getName());
	$smarty->assign('timestamp', time());
	$smarty->assign('hostname', $_SERVER['SERVER_NAME'] . ':' . $_SERVER['SERVER_PORT']);
	$smarty->assign('hash', $player_hash);
	$smarty->assign('log_id', $package->getLogID());
	$smarty->assign('PACKED', JS_PACKED);
	$smarty->assign('ANALYTICS', SHOW_ANALYTICS);
	$smarty->assign('SHOW_ADS', SHOW_ADS);
	$smarty->display('landing-beta.tpl');
}
catch (DatabaseException $e) {
	$smarty->display('failwhale.tpl');
}

?>
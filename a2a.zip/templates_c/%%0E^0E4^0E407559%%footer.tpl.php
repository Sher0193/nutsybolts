<?php /* Smarty version 2.6.18, created on 2007-10-20 22:16:24
         compiled from footer.tpl */ ?>
		<div class="bottom_link_row">
			<a href="about.php">About</a>
			<a href="faq.php">FAQ</a>
			<a href="contact.php">Contact</a>
		</div>

    </div>

</body>
</html>
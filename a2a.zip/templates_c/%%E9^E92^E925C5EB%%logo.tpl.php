<?php /* Smarty version 2.6.18, created on 2009-06-29 21:42:21
         compiled from logo.tpl */ ?>
<div class="logo">
	<a href="/" style="text-decoration: none;">
	<span style="padding-left: 20px;"><img src="/images/nb-logo.png" width="70" height="70" border="0" /></span>
	<span style="padding: 0px;"><img src="/images/a2a_logo_beta.png" width="360" height="70" border="0" /></span>
	</a>
</div>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "linkblock.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<div style="clear: both;"> </div>
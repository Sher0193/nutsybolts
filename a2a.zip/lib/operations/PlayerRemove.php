<?php

class PlayerRemove extends AJAXOperation {
	function process() {
		$room = new Room($this->player->getRoomID());
		$room->load();
		
		$status = $room->removePlayer($this->request['rid']);
		//error_log($status);
		if (!$status) return 0;
		return 1;
	}
}
?>
<?php

class IdleVote extends AJAXOperation {
	function process() {
		return $this->player->idleVote($this->request['v']);
	}
}

?>
<?php

class PlayerIgnore extends AJAXOperation {
	function process() {
		$this->player->ignore($this->request['i']);
	}
}

?>
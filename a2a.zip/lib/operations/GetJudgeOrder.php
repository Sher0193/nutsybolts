<?php

class GetJudgeOrder extends AJAXOperation {
	function process() {
		$room = new Room($this->request['r']);
		$room->load();
		return $room->getJudgeNumber();
	}
}

?>
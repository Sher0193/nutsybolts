<?php

class PlayerUnignore extends AJAXOperation {
	function process() {
		$this->player->unignore($this->request['i']);
	}
}

?>
<?php

require_once MODEL_DIR . 'RoomDeck.php';

class NounGetAll extends AJAXOperation {
	function process() {
		$room_deck = new RoomDeck(-1, 1);
		return join("\n", $room_deck->getAllRedCards());
	}
}

?>
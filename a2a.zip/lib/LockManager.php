<?php

class LockManager {
	private $room_id;
	private $locks;
	private $debug;
	
	function __construct($rid) {
		$this->room_id = $rid;
		$this->locks = array();
	}
	
	function lock($name, $exclusive) {
		if ($exclusive) {
			$open_mode = 'w';
			$lock_mode = LOCK_EX;
		}
		else {
			$open_mode = 'r';
			$lock_mode = LOCK_SH;
		}
		
		$filename = SEMAPHORE_DIR . $name . $this->room_id . '.semaphore';
		if (!file_exists($filename))
			touch($filename); // in case the file doesn't exist yet
		
		$fh = fopen($filename, $open_mode);
		if (flock($fh, $lock_mode)) {
			$this->locks[$name] = $fh;
			return true;
		}
	}
	
	function lockExclusive($name) { return $this->lock($name, true);  }
	function lockShared($name)    { return $this->lock($name, false); }
	
	function unlock($name) {
		flock($this->locks[$name], LOCK_UN);
		fclose($this->locks[$name]);
		unset($this->locks[$name]);
	}
	
	function __destruct() {
		foreach ($this->locks as $name => $fh) {
			//error_log('Unlocking ' . $name . ' on destruct');
			flock($fh, LOCK_UN);
			fclose($fh);
			unset($this->locks[$name]);
		}
	}
}

?>